clear
clc

load('Model2_Scenario1_Faulty.mat')

disp('Model2_Scenario1_Faulty');

fprintf('Number of falsified runs %f (over 50)  \n',sum([resultsModel2Scenario1Faulty.run.falsified]));

fprintf('Average Number of Iterations %f \n',mean(nonzeros([resultsModel2Scenario1Faulty.run.nTests].*[resultsModel2Scenario1Faulty.run.falsified])));

fprintf('Median Number of Iterations %f \n',median(nonzeros([resultsModel2Scenario1Faulty.run.nTests].*[resultsModel2Scenario1Faulty.run.falsified])));


load('Model2_Scenario1_Correct.mat')

disp('Model2_Scenario1_Correct');

fprintf('Number of falsified runs %f (over 50)  \n',sum([resultsModel2Scenario1Correct.run.falsified]));

fprintf('Average Number of Iterations %f \n',mean(nonzeros([resultsModel2Scenario1Correct.run.nTests].*[resultsModel2Scenario1Correct.run.falsified])));

fprintf('Median Number of Iterations %f \n',median(nonzeros([resultsModel2Scenario1Correct.run.nTests].*[resultsModel2Scenario1Correct.run.falsified])));


load('Model2_Scenario2_Faulty.mat')

disp('Model2_Scenario2_Faulty');

fprintf('Number of falsified runs %f (over 50)  \n',sum([resultsModel2Scenario2Faulty.run.falsified]));

fprintf('Average Number of Iterations %f \n',mean(nonzeros([resultsModel2Scenario2Faulty.run.nTests].*[resultsModel2Scenario2Faulty.run.falsified])));

fprintf('Median Number of Iterations %f \n',median(nonzeros([resultsModel2Scenario2Faulty.run.nTests].*[resultsModel2Scenario2Faulty.run.falsified])));



load('Model2_Scenario2_Correct.mat')

disp('Model2_Scenario2_Correct');

fprintf('Number of falsified runs  %f (over 50) \n',sum([resultsModel2Scenario2Correct.run.falsified]));

fprintf('Average Number of Iterations %f \n',mean(nonzeros([resultsModel2Scenario2Correct.run.nTests].*[resultsModel2Scenario2Correct.run.falsified])));

fprintf('Median Number of Iterations %f \n',median(nonzeros([resultsModel2Scenario2Correct.run.nTests].*[resultsModel2Scenario2Correct.run.falsified])));

