%staliro testing pacemaker model 
%group 1
warning('off');
close all;
clear;

global debug;
debug = 1;
model = 'Model2_Scenario1_Faulty';
%model = 'sldemo_autotrans_mod01';
init_cond = []; %initial conditions for the model
phi = '[](ventAmplitudeLowerThan5V)';

preds(1).str='ventAmplitudeLowerThan5V';
preds(1).A=1;
preds(1).b= 100;


time=15; %runtime for a single test run

opt=staliro_options();
opt.runs=50; %number of times to run
opt.optimization_solver = 'UR_Taliro';  %uniform random distribution

% the value of the mode are generated between 1,6. The model assign each value in [1,2) to 1 etc 
input_range = [1 5; 1 6; 0 2];

cp_array=[3 ; 2; 3];%contour points, one at the beginning, middle, and end

opt.interpolationtype = {'pchip','pconst','pchip'};
model = 'Model2_Scenario2_Faulty';
[resultsModel2Scenario2Faulty,history,opt]=staliro(model,init_cond,input_range,cp_array,phi,preds,time,opt);
save('Model2_Scenario2_Faulty');


model = 'Model2_Scenario2_Correct';
[resultsModel2Scenario2Correct,history,opt]=staliro(model,init_cond,input_range,cp_array,phi,preds,time,opt);
save('Model2_Scenario2_Correct');


