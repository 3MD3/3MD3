clear
clc

load('Model1_Scenario1_Faulty.mat')

disp('Model1_Scenario1_Faulty');

results=resultsModel1Scenario1Faulty;

fprintf('Number of falsified runs %f (over 50)  \n',sum([results.run.falsified]));

fprintf('Average Number of Iterations %f \n',mean(nonzeros([results.run.nTests].*[results.run.falsified])));

fprintf('Median Number of Iterations %f \n',median(nonzeros([results.run.nTests].*[results.run.falsified])));


load('Model1_Scenario1_Correct.mat')

disp('Model1_Scenario1_Correct');

results=resultsModel1Scenario1Correct;
fprintf('Number of falsified runs %f (over 50)  \n',sum([results.run.falsified]));

fprintf('Average Number of Iterations %f \n',mean(nonzeros([results.run.nTests].*[results.run.falsified])));

fprintf('Median Number of Iterations %f \n',median(nonzeros([results.run.nTests].*[results.run.falsified])));


load('Model1_Scenario2_Faulty.mat')
disp('Model1_Scenario2_Faulty');

results=resultsModel1Scenario2Faulty;
fprintf('Number of falsified runs %f (over 50)  \n',sum([results.run.falsified]));

fprintf('Average Number of Iterations %f \n',mean(nonzeros([results.run.nTests].*[results.run.falsified])));

fprintf('Median Number of Iterations %f \n',median(nonzeros([results.run.nTests].*[results.run.falsified])));


load('Model1_Scenario2_Correct.mat')

disp('Model1_Scenario2_Correct');

results=resultsModel1Scenario2Correct;
fprintf('Number of falsified runs  %f (over 50) \n',sum([results.run.falsified]));

fprintf('Average Number of Iterations %f \n',mean(nonzeros([results.run.nTests].*[results.run.falsified])));

fprintf('Median Number of Iterations %f \n',median(nonzeros([results.run.nTests].*[results.run.falsified])));

